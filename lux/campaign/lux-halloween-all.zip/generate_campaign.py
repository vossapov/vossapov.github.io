#!/usr/bin/env python3
"""Regenerate Lux demo campaign. Catalog is the sole price source. Requires Pillow/reportlab/pypdf/poppler."""
from pathlib import Path
import json, subprocess, shutil, sys, zipfile
from PIL import Image,ImageDraw,ImageFont,ImageOps
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader,PdfWriter
ROOT=Path(__file__).resolve().parents[1]; DIST=ROOT/'demo/dist'; OUT=DIST/'campaign'; OUT.mkdir(exist_ok=True)
CAT={p['id']:p for p in json.loads((DIST/'catalog.json').read_text())}
FONT=DIST/'assets/NotoSans-Regular.ttf'; BOLD=DIST/'assets/NotoSans-Bold.ttf'; LOGO=DIST/'assets/lux-logo.jpg'
DARK='#191b1c'; YELLOW='#ffcf24'; GREY='#aeb3b4'; WHITE='#ffffff'
DEMO='ДЕМО · ціни та акція вигадані'; DATES='24–31 ЖОВТНЯ 2026'; manifest=[]
def photo(id):
 p=DIST/f'assets/products/{id}.png'
 if not p.exists(): p=Path(f'/tmp/lux-product-photos/{id}.png')
 return p

def font(s,b=False): return ImageFont.truetype(str(BOLD if b else FONT),int(s))
def wrap(draw,t,s,w,b=False):
 lines=[]; line=''
 for word in t.split():
  test=(line+' '+word).strip()
  if draw.textlength(test,font=font(s,b))>w and line: lines.append(line); line=word
  else: line=test
 lines.append(line); return lines

def txt(d,t,xy,s,color=WHITE,b=False,w=None):
 x,y=xy
 for l in wrap(d,t,s,w,b) if w else [t]: d.text((x,y),l,font=font(s,b),fill=color); y+=s*1.24
 return y

def contained(im,path,box):
 x,y,w,h=map(int,box); src=Image.open(path).convert('RGB'); src.thumbnail((w,h),Image.Resampling.LANCZOS); im.paste(src,(x+(w-src.width)//2,y+(h-src.height)//2))
def social(pid,kind,W,H):
 p=CAT[pid]; im=Image.new('RGB',(W,H),DARK); d=ImageDraw.Draw(im); landscape=W>H; story=H/W>1.6
 m=54 if not landscape else 42
 d.rectangle((0,0,W,12),fill=YELLOW)
 top=200 if story else 38
 contained(im,LOGO,(m,top,116,116)); txt(d,'БУДМАРКЕТ ЛЮКС',(m+140,top+8),30,b=True);txt(d,'HALLOWEEN · '+DATES,(m+140,top+52),23,YELLOW,b=True)
 if landscape:
  txt(d,'СТРАШНО',(m,172),52,b=True);txt(d,'ВИГІДНІ ЦІНИ',(m,235),52,YELLOW,b=True)
  txt(d,p['name'],(m,318),32,b=True,w=555);txt(d,p['details'],(m,402),19,GREY,w=555)
  d.rounded_rectangle((655,156,1158,478),22,fill=WHITE);contained(im,photo(pid),(670,160,390,310))
  d.ellipse((1025,170,1143,288),fill=YELLOW); txt(d,f"-{p['discount']}%",(1034,202),31,DARK,True)
  price_y=444; price_x=m
  footer_y=523
 else:
  yy=350 if story else 182
  txt(d,'СТРАШНО',(m,yy),80,b=True);txt(d,'ВИГІДНІ ЦІНИ',(m,yy+92),70,YELLOW,True)
  card_y=yy+205; card_h=530 if story else (420 if H>1100 else 290)
  d.rounded_rectangle((m,card_y,W-m,card_y+card_h),28,fill=WHITE)
  contained(im,photo(pid),(m+35,card_y+12,W-2*m-110,card_h-24))
  d.ellipse((W-m-192,card_y+22,W-m-22,card_y+192),fill=YELLOW);txt(d,f"-{p['discount']}%",(W-m-178,card_y+71),47,DARK,True)
  name_y=card_y+card_h+25
  txt(d,p['name'],(m,name_y),38,b=True,w=W-2*m)
  txt(d,p['details'],(m,name_y+100 if len(p['name'])>31 else name_y+55),25,GREY,w=W-2*m)
  price_y=1395 if story else H-240; price_x=m
  footer_y=1570 if story else H-131
 # price band
 txt(d,f"{p['price']:,.0f}".replace(',',' '),(price_x,price_y),74 if not landscape else 58,YELLOW,True)
 pw=d.textlength(f"{p['price']:,.0f}".replace(',',' '),font=font(74 if not landscape else 58,True))
 txt(d,'грн / '+p['unit'],(price_x+pw+16,price_y+32),24,WHITE)
 old=f"{p['oldPrice']:,.0f} грн".replace(',',' '); ox=price_x+pw+200
 txt(d,old,(ox,price_y+34),23,GREY);d.line((ox,price_y+51,ox+d.textlength(old,font=font(23)),price_y+51),fill=GREY,width=2)
 d.line((m,footer_y-14,W-m,footer_y-14),fill='#45494b',width=2)
 fs=21 if landscape else 24
 txt(d,'Нова Одеса · вул. Вільна, 1',(m,footer_y),fs,b=True)
 txt(d,'097 429 47 85 · @_luxe.market_',(m,footer_y+32),fs,GREY)
 txt(d,DEMO,(m,1660 if story else H-40),19,YELLOW)
 name=f'{pid}-{kind}.png'
 if '--print-only' not in sys.argv: im.save(OUT/name,optimize=True)
 manifest.append(dict(id=f'{pid}-{kind}',title=p['name'],kind='social',format=kind,url='/campaign/'+name,preview='/campaign/'+name,width=W,height=H,productId=pid))

pdfmetrics.registerFont(TTFont('Noto',str(FONT)));pdfmetrics.registerFont(TTFont('NotoBold',str(BOLD)))
class Print:
 def __init__(self,name,w,h):
  self.name=name;self.w=w;self.h=h;self.mm=72/25.4;self.bleed=3*self.mm;self.c=canvas.Canvas(str(OUT/name),pagesize=((w+6)*self.mm,(h+6)*self.mm),initialFontName='Noto');self.c.setTitle('Будмаркет Люкс · Демонстраційна кампанія Halloween');self.c.setAuthor('Lux demo');self.page=0
 def start(self,bg=DARK):
  self.page+=1;self.c.saveState();self.c.translate(self.bleed,self.bleed);self.c.scale(self.mm,self.mm);self.rect(-3,-3,self.w+6,self.h+6,bg)
 def rect(self,x,y,w,h,col):
  self.c.setFillColor(col);self.c.rect(x,self.h-y-h,w,h,fill=1,stroke=0)
 def text(self,t,x,y,s=4,col=WHITE,b=False):
  self.c.setFillColor(col);self.c.setFont('NotoBold' if b else 'Noto',s);self.c.drawString(x,self.h-y-s,t)
 def image(self,path,x,y,w,h):
  self.c.drawImage(str(path),x,self.h-y-h,w,h,preserveAspectRatio=True,anchor='c',mask='auto')
 def end(self): self.c.restoreState();self.c.showPage()
 def save(self):
  self.c.save();r=PdfReader(OUT/self.name);w=PdfWriter()
  from pypdf.generic import RectangleObject
  for p in r.pages:
   p.trimbox=RectangleObject([self.bleed,self.bleed,(self.w+3)*self.mm,(self.h+3)*self.mm]);p.bleedbox=p.mediabox;w.add_page(p)
  with open(OUT/self.name,'wb') as f:w.write(f)
 def footer(self):
  if self.w>200:
   self.text('Нова Одеса · вул. Вільна, 1 | 097 429 47 85',28,self.h-46,7)
   self.text('Пн–Пт 8:00–19:00 · Сб–Нд 8:00–18:00 · @_luxe.market_',28,self.h-32,6,col=GREY)
   self.text(DEMO,28,self.h-18,6,col=YELLOW)
   return
  self.text('Нова Одеса · вул. Вільна, 1 | 097 429 47 85',10,self.h-26,3)
  self.text('Пн–Пт 8:00–19:00 · Сб–Нд 8:00–18:00 · @_luxe.market_',10,self.h-20,2.6,col=GREY)
  self.text(DEMO,10,self.h-12,2.8,col=YELLOW)

def hero_pdf(q):
 q.start();q.rect(-3,-3,q.w+6,4,YELLOW);k=q.w/148
 q.image(LOGO,10*k,10*k,25*k,25*k);q.text('HALLOWEEN У ЛЮКСІ',42*k,14*k,4*k,b=True);q.text(DATES,42*k,23*k,3.4*k,col=YELLOW)
 q.text('СТРАШНО',10*k,43*k,13*k,b=True);q.text('ВИГІДНІ ЦІНИ',10*k,60*k,11*k,col=YELLOW,b=True)
 q.text('ДЛЯ ДОМУ. ДЛЯ РЕМОНТУ. ДЛЯ ВАС.',10*k,81*k,3.4*k)
 hp=DIST/'assets/halloween-hero.png'
 if not hp.exists(): hp=Path('/tmp/lux-product-photos/halloween-hero.png')
 if hp.exists(): q.image(hp,10*k,93*k,128*k,59*k)
 else:
  q.rect(10*k,94*k,128*k,57*k,WHITE)
  for idx,pid in enumerate(['05','07','25']): q.image(photo(pid),(12+42*idx)*k,95*k,40*k,54*k)
 q.text('ЗНИЖКИ',10*k,157*k,6*k,b=True);q.text('5–50%',51*k,149*k,20*k,col=YELLOW,b=True)
 if q.w>200:
  q.text('На обрані товари демонстраційного каталогу',10*k,175*k,3.4*k)
  q.text('24–31 жовтня 2026 · Будмаркет Люкс',10*k,183*k,3.4*k)
 q.footer();q.end()

def item(q,pid,x,y,w,h):
 p=CAT[pid];q.rect(x,y,w,h,WHITE);q.image(photo(pid),x+2,y+2,w-4,25)
 q.rect(x+w-22,y,22,8,YELLOW);q.text(f"-{p['discount']}%",x+w-20,y+1,4,DARK,True)
 name=p['name'];lines=[];line=''
 for word in name.split():
  t=(line+' '+word).strip()
  if pdfmetrics.stringWidth(t,'NotoBold',3)>w-6 and line:lines.append(line);line=word
  else:line=t
 lines.append(line)
 for i,t in enumerate(lines):q.text(t,x+3,y+29+i*4,3,DARK,True)
 ds=min(2.5,(w-6)/pdfmetrics.stringWidth(p['details'],'Noto',1))
 q.text(p['details'],x+3,y+40,ds,'#555555')
 q.text(f"{p['oldPrice']:.0f} грн",x+3,y+46,3,'#777777');q.c.setStrokeColor('#777777');q.c.setLineWidth(.2);q.c.line(x+3,q.h-y-48,x+20,q.h-y-48)
 q.text(f"{p['price']:.0f} грн",x+3,y+51,6,DARK,True)
 q.text('/ '+p['unit'],x+w-20,y+55,2.6,DARK)

for pid in ['05','07','13','17','25']:
 for kind,w,h in [('instagram',1080,1350),('stories',1080,1920),('facebook',1200,630),('threads',1080,1080)]:social(pid,kind,w,h)
if '--social-only' in sys.argv:
 (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));sys.exit(0)
q=Print('lux-halloween-flyer-a5.pdf',148,210);hero_pdf(q)
for number,ids in enumerate([['05','06','07','10'],['13','17','22','25'],['27','28']]):
 q.start();q.rect(-3,-3,154,4,YELLOW);q.text('СТРАШНО ВИГІДНІ ЦІНИ',10,11,6,YELLOW,True);q.text(DATES+' · ЛЮКС',10,22,3.5)
 for i,pid in enumerate(ids):item(q,pid,10+(i%2)*66,34+(i//2)*67,62,63)
 if len(ids)==2:
  q.text('БІЛЬШЕ ЗНАХІДОК ДЛЯ ДОМУ',10,109,5,YELLOW,True)
  q.text('Будматеріали · сантехніка · електрика',10,124,3.6)
  q.text('Інструменти · техніка · посуд · іграшки',10,133,3.6)
  q.text('Завітайте до Люксу в Новій Одесі',10,150,4,b=True)
 q.footer();q.text(str(number+2),136,195,3,GREY);q.end()
q.save();q=Print('lux-halloween-poster-a2.pdf',420,594);hero_pdf(q);q.save()
for name,label,fmt,w,h in [('lux-halloween-flyer-a5.pdf','Флаєр · 10 товарів + обкладинка','A5 · 4 сторінки',148,210),('lux-halloween-poster-a2.pdf','Постер акції','A2 · 420 × 594 мм',420,594)]:
 prefix=OUT/name.replace('.pdf','');subprocess.run(['pdftoppm','-scale-to','1400','-png',str(OUT/name),str(prefix)],check=True)
 preview='/campaign/'+prefix.name+'-1.png'
 manifest.append(dict(id=prefix.name,title=label,kind='print',format=fmt,url='/campaign/'+name,preview=preview,width=w,height=h))
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(OUT/'production-notes.md').write_text('''# Виробничі примітки\n\nДемонстраційна кампанія: усі ціни, знижки, залишки й дати вигадані. Зображення товарів ілюстративні, AI-generated, не фото реального асортименту. Не є офіційною акцією магазину.\n\n- 5 товарних макетів × 4 формати: Instagram 1080×1350, Stories 1080×1920, Facebook 1200×630, Threads 1080×1080.\n- A5: 148×210 мм, 4 послідовні сторінки (обкладинка та 10 товарів), не спуск смуг.\n- A2: 420×594 мм, 1 сторінка.\n- Обидва PDF мають 3 мм вильоти, MediaBox/BleedBox і TrimBox; текст векторний, Noto Sans вкладений.\n- Колір RGB: перед друком друкарня має виконати пробу й конвертацію під свій ICC-профіль. Це макет для погодження, не сертифікований PDF/X.\n- Логотип оригінальний растровий 150×150 px, без перемальовування: приблизно 152 ppi на A5 та 54 ppi на A2. Для тиражу обов’язково отримати векторний логотип. AI-ілюстрація на A2 також потребує перевірки ефективної роздільності / заміни для високоякісного друку.\n- Джерело цін: ../catalog.json. Відтворення: scripts/generate_campaign.py.\n- Дизайн заснований на спостережених матеріалах соцмереж (темний фон, жовті акценти, оригінальний червоно-білий знак), не на офіційному брендбуку.\n''')
print(f'Generated {len(manifest)} assets')

with zipfile.ZipFile(OUT/'lux-halloween-all.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.iterdir()):
  if p.suffix in ['.png','.pdf','.md','.json']: z.write(p,p.name)
 z.write(Path(__file__),'generate_campaign.py')
